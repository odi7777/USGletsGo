//
//  BookStoreApp.swift
//  BookStore
//
//  Created by Ted Kim on 2023/07/27.
//

import SwiftUI

@main
struct BookStoreApp: App {
    
    @StateObject var store = Store()
    
    var body: some Scene {
        WindowGroup {
            MainView()
                .environmentObject(store)
        }
    }
}
