//
//  OrderView.swift
//  BookStoreFT
//
//  Created by Ted Kim on 2023/07/11.
//

import SwiftUI

struct OrderView: View {
    
    let product: Product
    @State private var name: String = ""
    @State private var address: String = ""
    @State private var quantity: Int = 1
    @State private var isShowingConfirmationAlert: Bool = false
    @Binding var isPresent: Bool

    var body: some View {
        VStack {
            VStack {
                Text("제품 정보")
                    .font(.title)
                    .padding()

                Image(product.productImage[0])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 200)
                    .cornerRadius(8)

                Text("제품명: \(product.productName)")
                    .font(.headline)

                Text("가격: \(product.price)원")
                    .font(.headline)
                    .padding(.top, 5.0)
            }
            

            Form {
                Section(header: Text("주문 정보")) {
                    TextField("이름", text: $name)
                    TextField("주소", text: $address)
                    Stepper("수량: \(quantity)", value: $quantity, in: 1...10)
                }
            }
            .padding()

            Button(action: {
                PlaceOrder()
            }) {
                Text("주문하기")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(8)
            }
            .padding()

            Spacer()
        }
        .alert(isPresented: $isShowingConfirmationAlert) {
            Alert(
                title: Text("주문 완료"),
                message: Text("주문이 성공적으로 완료되었습니다."),
                dismissButton: .default(Text("확인")) {
                    // "확인" 후 sheet를 닫기
                    isPresent = false
                }
            )
        }
        .navigationBarTitle("주문하기", displayMode: .inline)
    }

    private func PlaceOrder() {
        // 주문 처리 로직
        // 주문 정보 및 상품 정보를 사용하여 실제로 주문을 처리하는 코드 작성
        // 여기서는 단순히 주문 완료 알림만 보여줍니다.
        isShowingConfirmationAlert = true
    }
}

struct OrderView_Previews: PreviewProvider {
    static var previews: some View {
        OrderView(product: Store().products[1], isPresent: .constant(true))
            .environmentObject(Store())
    }
}
