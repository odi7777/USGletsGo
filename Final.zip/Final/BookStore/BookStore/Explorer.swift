//
//  Explorer.swift
//  BookStore
//
//  Created by Ted Kim on 2023/07/30.
//

import SwiftUI

struct Explorer: View {
    
    @EnvironmentObject var store: Store

    var body: some View {
        
        NavigationView {
            List(store.products) { product in
                NavigationLink(destination: ContentView(product: product)) {
                    ProductRow(product: product)
                }
            }
            .navigationBarTitle("BookStore")

        }
    }
}

struct Explorer_Previews: PreviewProvider {
    static var previews: some View {
        Explorer()
            .environmentObject(Store())
    }
}
