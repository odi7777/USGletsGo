//
//  ProductRow.swift
//  BookStoreFT
//
//  Created by Ted Kim on 2023/07/03.
//

import SwiftUI

struct ProductRow: View {
    
    let product: Product
    
    var body: some View {
        HStack {
            Image(product.productImage[0])
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
            Text(product.productName)
                .font(.headline)
                .lineLimit(1)
            Spacer()
            Text(product.user.name)
                .font(.caption)
        }
        
    }
}

struct ProductRow_Previews: PreviewProvider {
    static var previews: some View {
        ProductRow(product: productSample)
    }
}
