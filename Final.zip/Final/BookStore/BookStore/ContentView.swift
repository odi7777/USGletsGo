//
//  ContentView.swift
//  BookStoreFT
//
//  Created by Ted Kim on 2023/07/03.
//

import SwiftUI

struct ContentView: View {
    
    var product: Product
    
    @State private var currentImageIndex = 0
    @State var isSelected: Bool = false
    @State private var isOrderViewPresented = false
    
    var body: some View {
        VStack(alignment: .leading){
            productImage
            productDescription
            Spacer()
            buyNow
        }
    }
}

private extension ContentView {
    
    var productImage: some View {
        ZStack{
            //            Image(images[currentImageIndex])
            Image(product.productImage[currentImageIndex])
                .resizable()
                .scaledToFit()
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width*2/3)
            HStack {
                
                // show prev image
                Button {
                    currentImageIndex -= 1
                } label: {
                    Image(currentImageIndex > 0 ? "left_arrow" : "left_arrow_gray")
                }
                .disabled(!(currentImageIndex>0))
                
                Spacer()
                
                // show next image
                Button {
                    currentImageIndex += 1
                } label: {
                    Image(currentImageIndex < product.productImage.count - 1 ? "right_arrow" : "right_arrow_gray")
                }
                .disabled(!(currentImageIndex < product.productImage.count - 1))
                
                
                
            }
            .padding()
        }
    }
    
    var productDescription: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(product.productName)
                    .font(.title)
                
                Spacer()
                
                LikeButton(product: product)
            }
            
            HStack{
                if let userImage = product.user.image {
                    Image(userImage)
                        .resizable()
                        .frame(width: 40, height: 40, alignment: .leading)
                        .clipShape(Circle())
                }
                Text(product.user.name)

            }
            VStack(spacing: 5){
                HStack{
                    HStack{
                        Text("저자")
                            .frame(width: 60, alignment: .leading)
                        Text(product.author)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack{
                        Text("출판사")
                            .frame(width: 60, alignment: .leading)
                        Text(product.publisher)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                
                HStack{
                    HStack{
                        Text("출간일")
                            .frame(width: 60, alignment: .leading)
                        Text(product.publicationDate)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .padding(20)
    }
    
    var buyNow: some View {
        HStack {
            Spacer()
            Text("\(product.price)원")
                .font(.title2)
                .frame(width: 130, alignment: .trailing)
            Button {
                isOrderViewPresented = true
            } label: {
                Text("바로구매")
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Color.blue)
                    .cornerRadius(8)
            }
            .sheet(isPresented: $isOrderViewPresented) {
                OrderView(product: product, isPresent: $isOrderViewPresented)
            }
        }
        .padding([.bottom, .trailing], 20.0)
    }
}

struct LikeButton: View {
//    @Binding var isSelected: Bool
    @EnvironmentObject private var store: Store
    let product: Product
    
    private var imageName: String {
        guard let indexOfProduct = store.products.firstIndex(of: product) else { return "btn_heart_outline" }
        return store.products[indexOfProduct].isLiked ? "btn_heart_filled" : "btn_heart_outline"
    }
    
    var body: some View {
        Button(action: {
            store.toggleLike(of: product)
        }, label: {
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 40)
        })
    }
}

// MARK: - Previews

struct ContentView_Preview: PreviewProvider {
    static var previews: some View {
        ContentView(product: Store().products[1])
            .environmentObject(Store())
    }
}
