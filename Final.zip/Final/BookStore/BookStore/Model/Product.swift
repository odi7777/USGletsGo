//
//  Product.swift
//  BookStoreFT
//
//  Created by Ted Kim on 2023/07/09.
//

import Foundation

// ProductRow에서 사용하기 위해 선언
struct Product: Identifiable {
    var id = UUID()
    
    let productName: String
    let productImage: [String]
    let price: Int
    
    let author: String
    let publisher: String
    let publicationDate: String
    
    let user: User
    
    var isLiked: Bool = false
}

extension Product: Equatable {
    static func == (lhs: Product, rhs: Product) -> Bool {
        return lhs.id == rhs.id
    }
}

// Preview의 파라미터로 사용하기 위해 선언
let productSample: Product = Product(productName: "자기관리론", productImage: ["자기관리론_1", "자기관리론_2", "자기관리론_3", "자기관리론_4"], price: 21000, author: "저자B", publisher: "출판사B", publicationDate: "2021-12-15", user: User.월령공주)
