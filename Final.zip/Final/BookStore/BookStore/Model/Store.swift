//
//  Store.swift
//  BookStoreFT
//
//  Created by Ted Kim on 2023/07/09.
//

import Foundation

final class Store: ObservableObject {
    @Published private(set) var products: [Product]
    @Published var likedProducts: [Product] = []

    func toggleLike(of product: Product) {
        guard let indexOfProduct = products.firstIndex(of: product) else { return }
        products[indexOfProduct].isLiked.toggle()

        // likedProducts에 추가하기
        if products[indexOfProduct].isLiked {
            likedProducts.append(product)
        }
        // likedProducts에서 삭제하기
        else {
            guard let indexOfProduct = likedProducts.firstIndex(of: product) else { return }
            likedProducts.remove(at: indexOfProduct)
        }
    }
    
    // 생성자
    init() {
        self.products = [
            Product(productName: "빛의 제국", productImage: ["빛의 제국"], price: 19000, author: "저자A", publisher: "출판사A", publicationDate: "2022-01-01", user: .테드),
            Product(productName: "자기관리론", productImage: ["자기관리론_1", "자기관리론_2", "자기관리론_3", "자기관리론_4"], price: 19000, author: "저자B", publisher: "출판사B", publicationDate: "2021-12-15", user: .월령공주),
            Product(productName: "작은 아씨들", productImage: ["작은 아씨들"], price: 19000, author: "저자C", publisher: "출판사C", publicationDate: "2022-03-10", user: .디바),
            Product(productName: "신경 끄기의 기술", productImage: ["신경 끄기의 기술"], price: 19000, author: "저자D", publisher: "출판사D", publicationDate: "2022-06-20", user: .키키),
            Product(productName: "세이노의 가르침", productImage: ["세이노의 가르침"], price: 19000, author: "저자E", publisher: "출판사E", publicationDate: "2021-09-05", user: .테드),
            Product(productName: "문과 남자의 과학 공부", productImage: ["문과 남자의 과학 공부"], price: 19000, author: "저자F", publisher: "출판사F", publicationDate: "2023-02-28", user: .월령공주),
            Product(productName: "아기와 놀아 주는 꼬꼬맘", productImage: ["아기와 놀아 주는 꼬꼬맘"], price: 19000, author: "저자G", publisher: "출판사G", publicationDate: "2022-07-10", user: .디바),
            Product(productName: "꿀벌의 예언 1", productImage: ["꿀벌의 예언 1"], price: 19000, author: "저자H", publisher: "출판사H", publicationDate: "2023-04-15", user: .키키),
            Product(productName: "역행자(확장판)", productImage: ["역행자(확장판)"], price: 19000, author: "저자I", publisher: "출판사I", publicationDate: "2022-11-30", user: .테드),
            Product(productName: "1984", productImage: ["1984"], price: 19000, author: "저자J", publisher: "출판사J", publicationDate: "1949-06-08", user: .월령공주)
        ]
    }
}
