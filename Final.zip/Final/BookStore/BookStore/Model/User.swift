//
//  User.swift
//  BookStoreFT
//
//  Created by Ted Kim on 2023/07/09.
//

import Foundation

class User: Identifiable {
    var id = UUID()
    
    var name: String
    var image: String?
    
    // 생성자
    init(name: String, image: String?) {
        self.name = name
        self.image = image
    }
    
    // 미리 생성한 유저 정보
    static let 테드 = User(name: "테드", image:"테드")
    static let 월령공주 = User(name: "월령공주", image:"월령공주")
    static let 디바 = User(name: "디바", image:"디바")
    static let 키키 = User(name: "키키", image:"키키")
    
}
