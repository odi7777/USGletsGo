//
//  LikedView.swift
//  NewStart
//
//  Created by eojin on 2023/08/24.
//

import SwiftUI

struct LikedView: View {
    
    @EnvironmentObject var store: Store
    
//    let product : Product
    
    var body: some View {
        NavigationView{
            List(store.likedProducts){
                product in ProductRow(product: product)
            }
            .navigationTitle("Liked Member")
            
//            VStack{
//                List(productSample) { item in
//                    NavigationLink(destination: ContentView(product: product)) { ProductRow(product: product)}
//                }
//            }
            
        }
    }
}

// 선택된 Liked 객체들을 Liked Member view에서 클릭해 들어가 정보를 볼 수 있게 하려면 임의의 선택된 객체가 들어오면 링크를 따라 ContentView 형식으로 볼 수 있도록 NavigationLink달고 destination을 ContentView로 설정해두면 되는건가?

struct LikedView_Previews: PreviewProvider {
    static var previews: some View {
        LikedView()
            .environmentObject(Store())
    }
}
