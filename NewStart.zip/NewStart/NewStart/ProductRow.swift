//
//  ProductRow.swift
//  NewStart
//
//  Created by eojin on 2023/08/10.
//

import SwiftUI

struct ProductRow: View {
    
    let product: Product
    
    var body: some View {
        HStack{
            Image(product.productImage[0])
                .resizable()
                .scaledToFit()
                .frame(width: 44, height: 44)
            Text(product.productName)
                .font(.headline)
            Spacer()
            
            Text("궁합도")
            Text("N")
            Image(systemName: "percent")
            Text(product.userName)
                .font(.callout)
        }
    }
}

struct ProductRow_Previews: PreviewProvider {
    static var previews: some View {
        ProductRow(product: productSample)
    }
}
