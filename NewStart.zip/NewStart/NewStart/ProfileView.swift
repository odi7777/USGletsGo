//
//  ProfileView.swift
//  NewStart
//
//  Created by eojin on 2023/08/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        
        VStack{
            Text("MyProfile")
            Spacer()
            Text("팀쿡")
            Image("팀쿡")
                .resizable()
                .scaledToFit()
                .frame(width: 80)
            Text("MBTI:      ENTP")
            Text("직군:       CEO")
            Spacer()
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
