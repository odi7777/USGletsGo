//
//  NewStartApp.swift
//  NewStart
//
//  Created by eojin on 2023/07/31.
//

import SwiftUI

@main
struct NewStartApp: App {
    
    @StateObject var store: Store = Store()
    
    var body: some Scene {
        WindowGroup {
            MainView()
                .environmentObject(store)
        }
    }
}
