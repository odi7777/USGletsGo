//
//  Explorer.swift
//  NewStart
//
//  Created by eojin on 2023/08/10.
//

import SwiftUI

struct Explorer: View {
    
    
    struct Product: Identifiable {
        var id = UUID()
        
        let userName: String
        let productName: String
        let productImage: [String]
        let profileimage: String
        
        let job: String
        let TMI: String
        
        let user: User
    }
    
    @EnvironmentObject var store: Store
    
    var body: some View {
        
        NavigationView {
            List(store.products) { product in
                NavigationLink(destination: ContentView(product: product)){
                    ProductRow(product: product)
                }
                .navigationTitle("MBTI팅")
            }
        }
    }
}
    
    struct Explorer_Previews: PreviewProvider {
        static var previews: some View {
            Explorer().environmentObject(Store())
        }
    }
