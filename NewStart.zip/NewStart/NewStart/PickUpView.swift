//
//  PickUpView.swift
//  NewStart
//
//  Created by eojin on 2023/08/24.
//

import SwiftUI

struct PickUpView: View {
    
    var body: some View {
        
        Text("PickUpView")
    }
}

struct PickUpView_Previews: PreviewProvider {
    static var previews: some View {
        PickUpView()
    }
}

// URL Session 통신 단계

// 데이터는 동기/비동기 형태로 보내주고 동기로 보내줄 경우 데이터를 전부 보내주는 과정이며 비동기의 경우 데이터를 세션별로 나누어 쪼개서 백그라운드에서 도착하는대로 메인뷰로 보내줌.
// 1. Model 생성 - Book 모델

// 2. URL Session을 사용해서 웹에 요청(응답 주고받기) - 코드들이 크게 다르지 않아 구글 API 예시자료 그대로 쓰면 됨.

//   - fatch객체이름 메소드를 사용해 정보를 싹 긁어옴(ex fatchBooks, fatchProduct 등)
// 3. 가져온 데이터를 준비한 Model - 그들만의 모델로 디코딩

// 4. API의 응답을 받아옴

// 5. 응답 데이터 처리로 Protocol을 보내줌.

// 파일 전송은 Json으로 보내줌.(Json사이트 참조해 데이터 보내주는 예시 형식을 보고 보내주기)
// 다만 데이터를 가져올때 (nil)이 되는 것을 막기위해 ??, [] 등의 공란을 만들어주기
// 가져올 URL의 API에서 보내주는 값이 무엇인지 보내주는 "Postman"에 URL을 붙여넣어서 가져오는 데이터를 확인할 수 있음.

// 공공 API 목록은 공공데이터포털 등에서 찾아쓸 수 있음. or Data.GOV 등 다양하게 API활용 가능.
