//
//  MainView.swift
//  NewStart
//
//  Created by eojin on 2023/08/24.
//

import SwiftUI

struct MainView: View {
    
    
    var body: some View {
        TabView{
            Explorer()
                .tabItem {
                    Image(systemName: "house")
                    Text("Exploler")
                }
            LikedView()
                .tabItem {
                    Image(systemName: "heart")
                    Text("Liked PickUp")
                }
            ProfileView()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Profile")
                }
        }
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
            .environmentObject(Store())
    }
}
