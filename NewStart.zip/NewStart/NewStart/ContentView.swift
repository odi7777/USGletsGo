//
//  ContentView.swift
//  NewStart
//
//  Created by eojin on 2023/07/31.
//

import SwiftUI


struct ContentView: View {
    
    var product: Product
    
    @State private var currentImageIndex = 0
    @State var isSelected: Bool = false
    @State private var isPickUpViewPresented = false
    
    
    
    var body: some View {
        VStack(alignment: .leading) {
            productImage
            productDescription
            Spacer()
            gettomyground
        }
        .padding()
    }
}


//왜 private extension을 써야 Vstack에 정리해놓은 view들이 정상적으로 작동하는지 질문하기.
// -> extension으로 view들을 나누어서 필요할 때 끌어써야함.
private extension ContentView {
    
    
    var productImage: some View{
        ZStack{
            Image(product.productImage[currentImageIndex])
                .resizable()
                .scaledToFit()
            
            // frame 설정은 내가 임의로 커스터마이징 가능한데, UIScreen은 기기화면 비율에 상관없이 동일한 비율로 화면설정이 가능하게 함.
            // 단, width*2/3의 경우는 이미지를 화면의 2/3만큼 맞춰주는 것.
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width*2/3 )
            
            HStack{
                
                Button {
                    //action
                    currentImageIndex -= 1
                } label: {
                    Image(currentImageIndex > 0 ? "left_arrow" : "left_arrow_gray")
                }
                .disabled(!(currentImageIndex > 0))
                .padding(10)
                
                Spacer()
                
                Button {
                    //action
                    currentImageIndex += 1
                } label: {
                    Image(currentImageIndex < product.productImage.count - 1 ?  "right_arrow" : "right_arrow_gray")
                }
                .disabled(!(currentImageIndex < product.productImage.count - 1))
            }
            .padding(20)
        }
}
        
        var productDescription: some View{
            
            
            VStack{
                VStack {
                    HStack{
                        Text(product.productName)
                            .font(.title)
                        
                    }
                    HStack{
                        Image(product.user.image)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 60)
                            .padding(10)
                        Text(product.user.name)
                        LikeButton(product: product)
                        Spacer()
                    }
                    
                    
                }
                
                VStack{
                    HStack{
                        Text("직군")
                            .frame(width: 50, alignment: .leading)
                        Text(product.job)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    HStack{
                        Text("TMI")
                            .frame(width: 50, alignment: .leading)
                        Text(product.TMI)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(10)
            }
            .padding(10)
        }
    }
    //네비게이션뷰{
    //List(0//<10){ row in
    //NavigationLink(destination: Text("Detail View: \(row)")){Text("List namber \(row)")
    //}
    

    var gettomyground: some View {
        
        HStack {
            Spacer()
            Button {
//                isPickUpViewPresented = true
            } label: {
                Text("소통하기")
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Color.green)
                    .cornerRadius(8)
                
            }
//            .sheet(isPresented:  $isPickUpViewPresented) {
//                PickUpView()
            }
            .padding(16)
        }
        
//    }


//bind는 함수를 호출하는 함수이고 해당 함수는 3항연산자를 통해 실행함.
//3항연산자: 변수(조건이 ? "참인 경우의 값" : "거짓인 경우의 값")
//굳이 likebutton(isselected:$iselected)를 붙이는 이유는 다른 view에서도 좋아요 기능이 적용되야 하기에 따로 binding으로 불러내서 사용함.

struct LikeButton: View {
//    @Binding var isSelected: Bool
    @EnvironmentObject var store: Store
    let product: Product
    
    var imageName: String {
        guard let indexOfProduct = store.products.firstIndex(of: product)
        else { return "btn_heart_outline" }
        return store.products[indexOfProduct].isLiked ? "btn_heart_filled" : "btn_heart_outline"
    }
    
    var body: some View {
        Button(action: {
//            isSelected.toggle()
            store.toggleLike(of: product)
        }, label: {
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 40)
        })
    }
}

struct Chattview: View{
    var body: some View{
        Text("홍길동님과의 채팅방입니다")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(product: Store().products[1])
            .environmentObject(Store())
//        (product: Product(userName: "테드", productName: "INFP", productImage: ["infp"],profileimage: "맹구", job: "CS팀", TMI: "E 접근금지", user: User.맹구))
    }
}
