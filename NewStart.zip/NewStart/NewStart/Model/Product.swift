//
//  Product.swift
//  NewStart
//
//  Created by eojin on 2023/08/24.
//

import Foundation

struct Product: Identifiable {
    var id = UUID()
    
    let userName: String
    let productName: String
    let productImage: [String]
    let profileimage: String
    
    let job: String
    let TMI: String
    
    let user: User
    
    var isLiked: Bool = false
}


extension Product: Equatable{
    static func == (lhs: Product, rhs: Product) -> Bool {
        return lhs.id == rhs.id
    }
    
}

let productSample: Product = Product(userName:"테드" ,productName: "INFP", productImage: ["infp"],profileimage: "맹구",job: "CS팀", TMI: "E 접근금지", user: User.맹구)
