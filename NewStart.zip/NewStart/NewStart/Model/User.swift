//
//  User.swift
//  NewStart
//
//  Created by eojin on 2023/08/11.
//

import Foundation

class User: Identifiable {
    var id = UUID()
    
    var name: String
    var image: String
    
    
    //생성자
    init(name: String, image: String){
        self.name = name
        self.image = image
    }
    
    //미리 생성된 유저 정보
    static let 맹구 = User(name: "테드", image: "맹구")
    static let 루피 = User(name: "제드", image: "루피")
    static let 곰 = User(name: "미드", image: "곰")
    static let 짱구 = User(name: "일드", image: "짱구")
}
