//
//  Store.swift
//  NewStart
//
//  Created by eojin on 2023/08/17.
//

import Foundation

class Store: ObservableObject{
    @Published private(set) var products: [Product]
    @Published var likedProducts: [Product] = []
    
    // guard를 사용해 해당되지 않는 대상에 동작을 가했을 때 크랙이 발생하지 않게 코드를 보호해줌.
    func toggleLike(of product: Product) {
        guard let indexOfProduct = products.firstIndex(of: product) else {return}
        products[indexOfProduct].isLiked.toggle()
        
            // likedProducts에 추가하기
        if products[indexOfProduct].isLiked {
            likedProducts.append(product)
        }
            //likedProducts에서 삭제하기
        else {
            guard let indexofProduct = likedProducts.firstIndex(of: product) else { return }
            likedProducts.remove(at: indexOfProduct)
        }
    }
    
    //생성자
    init() {
        self.products = [
        Product(userName: "테드", productName: "INFP", productImage: ["infp"], profileimage: "맹구",job: "CS팀", TMI: "E접근금지", user: User.맹구),
        Product(userName: "제드", productName: "ISFP", productImage: ["isfp"],profileimage: "루피", job: "백팀", TMI: "안녕", user: User.루피),
        Product(userName: "미드", productName: "ENFP", productImage: ["enfp"], profileimage: "곰",job: "PM팀", TMI: "하이", user: User.곰),
        Product(userName: "일드", productName: "ENTP", productImage: ["entp"],profileimage: "짱구", job: "인사관리팀", TMI: "헬로", user: User.짱구)
    ]
        
    }
}
